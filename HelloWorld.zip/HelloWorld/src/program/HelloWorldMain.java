package program;

public class HelloWorldMain {

	/**
     * The main method of this program.
     *
     * @param args Arguments passed to this program.
     */
	public static void main(String[] args) {
		HelloWorld hello = new HelloWorld();
		hello.sayHello(5);
	}
}
